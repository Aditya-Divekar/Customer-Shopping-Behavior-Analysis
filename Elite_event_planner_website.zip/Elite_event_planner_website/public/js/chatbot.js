// Intelligent Chatbot for NextEra Event Planner
class EventPlannerChatbot {
    constructor() {
        this.isOpen = false;
        this.messages = [];
        this.currentStep = 'welcome';
        this.userInfo = {};
        this.init();
    }

    init() {
        this.createChatbotHTML();
        this.bindEvents();
        this.addWelcomeMessage();
    }

    createChatbotHTML() {
        const chatbotHTML = `
            <div class="chatbot-container">
                <button class="chatbot-toggle" id="chatbotToggle">
                    <i class="fas fa-comments"></i>
                </button>
                <div class="chatbot-window" id="chatbotWindow">
                    <div class="chatbot-header">
                        <div>
                            <h3>NextEra Assistant</h3>
                            <div class="chatbot-status">
                                <div class="chatbot-status-dot"></div>
                                <span>Online</span>
                            </div>
                        </div>
                        <button class="chatbot-close" id="chatbotClose">
                            <i class="fas fa-times"></i>
                        </button>
                    </div>
                    <div class="chatbot-messages" id="chatbotMessages"></div>
                    <div class="chatbot-input-container">
                        <div class="quick-actions" id="quickActions">
                            <button class="quick-action" data-action="services">Our Services</button>
                            <button class="quick-action" data-action="pricing">Pricing</button>
                            <button class="quick-action" data-action="contact">Contact Info</button>
                            <button class="quick-action" data-action="booking">Book Event</button>
                        </div>
                        <div class="chatbot-input-wrapper">
                            <textarea class="chatbot-input" id="chatbotInput" placeholder="Ask me anything about our services..." rows="1"></textarea>
                            <button class="chatbot-send" id="chatbotSend">
                                <i class="fas fa-paper-plane"></i>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        `;

        document.body.insertAdjacentHTML('beforeend', chatbotHTML);
    }

    bindEvents() {
        const toggle = document.getElementById('chatbotToggle');
        const close = document.getElementById('chatbotClose');
        const send = document.getElementById('chatbotSend');
        const input = document.getElementById('chatbotInput');
        const quickActions = document.getElementById('quickActions');

        toggle.addEventListener('click', () => this.toggleChatbot());
        close.addEventListener('click', () => this.closeChatbot());
        send.addEventListener('click', () => this.sendMessage());
        
        input.addEventListener('keypress', (e) => {
            if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                this.sendMessage();
            }
        });

        input.addEventListener('input', () => {
            this.autoResize(input);
        });

        quickActions.addEventListener('click', (e) => {
            if (e.target.classList.contains('quick-action')) {
                const action = e.target.dataset.action;
                this.handleQuickAction(action);
            }
        });
    }

    toggleChatbot() {
        this.isOpen = !this.isOpen;
        const window = document.getElementById('chatbotWindow');
        const toggle = document.getElementById('chatbotToggle');
        
        if (this.isOpen) {
            window.classList.add('active');
            toggle.classList.add('active');
            document.getElementById('chatbotInput').focus();
        } else {
            window.classList.remove('active');
            toggle.classList.remove('active');
        }
    }

    closeChatbot() {
        this.isOpen = false;
        const window = document.getElementById('chatbotWindow');
        const toggle = document.getElementById('chatbotToggle');
        window.classList.remove('active');
        toggle.classList.remove('active');
    }

    addWelcomeMessage() {
        const welcomeMessage = `
            👋 Hello! I'm your NextEra Event Planner assistant. I can help you with:
            <br><br>
            🎉 <strong>Our Services:</strong> Wedding planning, birthday parties, corporate events, catering, decoration, photography
            <br>
            💰 <strong>Pricing:</strong> Get quotes for different event types and packages
            <br>
            📞 <strong>Contact:</strong> Phone, email, location, and working hours
            <br>
            📅 <strong>Booking:</strong> Help you book your perfect event
            <br><br>
            What would you like to know? 😊
        `;
        this.addMessage('bot', welcomeMessage);
    }

    sendMessage() {
        const input = document.getElementById('chatbotInput');
        const message = input.value.trim();
        
        if (!message) return;

        this.addMessage('user', message);
        input.value = '';
        this.autoResize(input);

        // Show typing indicator
        this.showTyping();

        // Process message after a short delay
        setTimeout(() => {
            this.processMessage(message);
        }, 1000);
    }

    showTyping() {
        const messagesContainer = document.getElementById('chatbotMessages');
        const typingMessage = document.createElement('div');
        typingMessage.className = 'message typing';
        typingMessage.innerHTML = `
            <span>Assistant is typing</span>
            <div class="typing-dots">
                <div class="typing-dot"></div>
                <div class="typing-dot"></div>
                <div class="typing-dot"></div>
            </div>
        `;
        messagesContainer.appendChild(typingMessage);
        this.scrollToBottom();

        // Remove typing indicator after response
        setTimeout(() => {
            if (typingMessage.parentNode) {
                typingMessage.parentNode.removeChild(typingMessage);
            }
        }, 2000);
    }

    processMessage(message) {
        const lowerMessage = message.toLowerCase();
        let response = '';

        // Service-related queries
        if (this.containsAny(lowerMessage, ['service', 'what do you offer', 'wedding', 'birthday', 'corporate', 'catering', 'decoration', 'photography'])) {
            response = this.getServicesResponse(lowerMessage);
        }
        // Pricing queries
        else if (this.containsAny(lowerMessage, ['price', 'cost', 'budget', 'how much', 'quote', 'pricing'])) {
            response = this.getPricingResponse(lowerMessage);
        }
        // Contact queries
        else if (this.containsAny(lowerMessage, ['contact', 'phone', 'email', 'address', 'location', 'hours', 'working'])) {
            response = this.getContactResponse();
        }
        // Booking queries
        else if (this.containsAny(lowerMessage, ['book', 'booking', 'schedule', 'reserve', 'plan event'])) {
            response = this.getBookingResponse();
        }
        // About queries
        else if (this.containsAny(lowerMessage, ['about', 'who are you', 'company', 'experience', 'team'])) {
            response = this.getAboutResponse();
        }
        // Greeting queries
        else if (this.containsAny(lowerMessage, ['hello', 'hi', 'hey', 'good morning', 'good afternoon', 'good evening'])) {
            response = this.getGreetingResponse();
        }
        // Help queries
        else if (this.containsAny(lowerMessage, ['help', 'what can you do', 'assist'])) {
            response = this.getHelpResponse();
        }
        // Default response
        else {
            response = this.getDefaultResponse();
        }

        this.addMessage('bot', response);
    }

    getServicesResponse(message) {
        if (this.containsAny(message, ['wedding'])) {
            return `
                💒 <strong>Wedding Planning Services</strong><br><br>
                We offer complete wedding planning from engagement to reception:
                <br>• Venue selection and booking
                <br>• Complete decoration and setup
                <br>• Premium catering services
                <br>• Photography & videography
                <br>• Entertainment coordination
                <br>• Guest management
                <br><br>
                <strong>Starting from ₹2,50,000</strong><br>
                <button class="service-suggestion" onclick="chatbot.handleQuickAction('booking')">
                    <h4>Book Your Wedding</h4>
                    <p>Get a personalized quote for your special day</p>
                </button>
            `;
        }
        else if (this.containsAny(message, ['birthday', 'party'])) {
            return `
                🎂 <strong>Birthday Celebrations</strong><br><br>
                Make every birthday special with our creative services:
                <br>• Themed decorations
                <br>• Custom birthday cakes
                <br>• Entertainment setup
                <br>• Party favors and gifts
                <br>• Photo booth services
                <br>• Catering for all ages
                <br><br>
                <strong>Starting from ₹15,000</strong><br>
                <button class="service-suggestion" onclick="chatbot.handleQuickAction('booking')">
                    <h4>Plan Birthday Party</h4>
                    <p>Create magical memories for your loved ones</p>
                </button>
            `;
        }
        else if (this.containsAny(message, ['corporate', 'business', 'conference', 'seminar'])) {
            return `
                💼 <strong>Corporate Events</strong><br><br>
                Professional event management for business needs:
                <br>• Conference setup and management
                <br>• AV equipment and technical support
                <br>• Professional catering services
                <br>• Networking facilitation
                <br>• Registration management
                <br>• Branding and signage
                <br><br>
                <strong>Starting from ₹75,000</strong><br>
                <button class="service-suggestion" onclick="chatbot.handleQuickAction('booking')">
                    <h4>Plan Corporate Event</h4>
                    <p>Impress your clients and colleagues</p>
                </button>
            `;
        }
        else if (this.containsAny(message, ['catering', 'food', 'menu'])) {
            return `
                🍽️ <strong>Premium Catering Services</strong><br><br>
                Exquisite culinary experiences with diverse options:
                <br>• Multi-cuisine menu options
                <br>• Live cooking stations
                <br>• Dietary accommodations
                <br>• Professional serving staff
                <br>• Premium tableware
                <br>• Beverage services
                <br><br>
                <strong>Starting from ₹500 per person</strong><br>
                <button class="service-suggestion" onclick="chatbot.handleQuickAction('booking')">
                    <h4>Get Catering Quote</h4>
                    <p>Delight your guests with our culinary expertise</p>
                </button>
            `;
        }
        else if (this.containsAny(message, ['decoration', 'decor', 'theme'])) {
            return `
                🎨 <strong>Event Decoration Services</strong><br><br>
                Transform any space into a magical setting:
                <br>• Custom theme design
                <br>• Floral arrangements
                <br>• Lighting design and setup
                <br>• Stage and backdrop setup
                <br>• Table decorations
                <br>• Entrance decorations
                <br><br>
                <strong>Starting from ₹25,000</strong><br>
                <button class="service-suggestion" onclick="chatbot.handleQuickAction('booking')">
                    <h4>Design Your Event</h4>
                    <p>Create the perfect atmosphere for your celebration</p>
                </button>
            `;
        }
        else if (this.containsAny(message, ['photography', 'photo', 'video', 'videography'])) {
            return `
                📸 <strong>Photography & Videography</strong><br><br>
                Capture every precious moment professionally:
                <br>• Professional event photography
                <br>• HD video documentation
                <br>• Photo editing and retouching
                <br>• Digital photo albums
                <br>• Video editing and highlights
                <br>• Drone photography (if applicable)
                <br><br>
                <strong>Starting from ₹35,000</strong><br>
                <button class="service-suggestion" onclick="chatbot.handleQuickAction('booking')">
                    <h4>Book Photography</h4>
                    <p>Preserve your memories forever</p>
                </button>
            `;
        }
        else {
            return `
                🎉 <strong>Our Complete Services</strong><br><br>
                We offer comprehensive event planning and catering services:
                <br><br>
                💒 <strong>Wedding Planning</strong> - Complete wedding coordination
                <br>🎂 <strong>Birthday Celebrations</strong> - Themed parties for all ages
                <br>💼 <strong>Corporate Events</strong> - Professional business events
                <br>🍽️ <strong>Premium Catering</strong> - Multi-cuisine dining experiences
                <br>🎨 <strong>Event Decoration</strong> - Custom themes and designs
                <br>📸 <strong>Photography & Video</strong> - Professional documentation
                <br><br>
                <button class="service-suggestion" onclick="chatbot.handleQuickAction('booking')">
                    <h4>Get Started Today</h4>
                    <p>Let us help you plan your perfect event</p>
                </button>
            `;
        }
    }

    getPricingResponse(message) {
        return `
            💰 <strong>Our Pricing Structure</strong><br><br>
            
            <strong>Wedding Planning:</strong>
            <br>• Basic Package: ₹2,50,000
            <br>• Premium Package: ₹4,00,000
            <br>• Luxury Package: ₹6,00,000
            <br><br>
            
            <strong>Birthday Celebrations:</strong>
            <br>• Basic Package: ₹15,000
            <br>• Premium Package: ₹30,000
            <br>• Luxury Package: ₹50,000
            <br><br>
            
            <strong>Corporate Events:</strong>
            <br>• Basic Package: ₹75,000
            <br>• Premium Package: ₹1,50,000
            <br>• Luxury Package: ₹2,50,000
            <br><br>
            
            <strong>Other Services:</strong>
            <br>• Catering: Starting ₹500 per person
            <br>• Decoration: Starting ₹25,000
            <br>• Photography: Starting ₹35,000
            <br><br>
            
            <em>All prices are customizable based on your specific requirements. Contact us for a detailed quote!</em>
            <br><br>
            <button class="service-suggestion" onclick="chatbot.handleQuickAction('contact')">
                <h4>Get Custom Quote</h4>
                <p>Contact us for personalized pricing</p>
            </button>
        `;
    }

    getContactResponse() {
        return `
            📞 <strong>Contact Information</strong><br><br>
            
            <strong>📍 Location:</strong><br>
            Chh. Sambhajinagar<br>
            Maharashtra, 431001<br><br>
            
            <strong>📱 Phone:</strong><br>
            +91 9665411782<br><br>
            
            <strong>📧 Email:</strong><br>
            NextEraplanner@gmail.com<br><br>
            
            <strong>🕒 Working Hours:</strong><br>
            Mon - Fri: 9:00 AM - 10:00 PM<br>
            Sat - Sun: 10:00 AM - 4:00 PM<br><br>
            
            <strong>Why Choose Us?</strong><br>
            ✅ 500+ Events Completed<br>
            ✅ 98% Client Satisfaction<br>
            ✅ 5+ Years Experience<br>
            ✅ 24/7 Customer Support<br><br>
            
            <button class="service-suggestion" onclick="chatbot.handleQuickAction('booking')">
                <h4>Book Your Event</h4>
                <p>Get started with your perfect event today</p>
            </button>
        `;
    }

    getBookingResponse() {
        return `
            📅 <strong>Book Your Perfect Event</strong><br><br>
            
            Ready to create unforgettable memories? Here's how to get started:
            <br><br>
            <strong>1. Choose Your Event Type:</strong><br>
            • Wedding Planning<br>
            • Birthday Celebrations<br>
            • Corporate Events<br>
            • Catering Services<br>
            • Event Decoration<br>
            • Photography & Videography<br><br>
            
            <strong>2. Contact Us:</strong><br>
            📞 Call: +91 9665411782<br>
            📧 Email: NextEraplanner@gmail.com<br><br>
            
            <strong>3. What We Need:</strong><br>
            • Event date and time<br>
            • Number of guests<br>
            • Venue location<br>
            • Budget range<br>
            • Special requirements<br><br>
            
            <strong>4. Our Process:</strong><br>
            • Free consultation<br>
            • Customized proposal<br>
            • Detailed planning<br>
            • Perfect execution<br><br>
            
            <button class="service-suggestion" onclick="window.location.href='#booking'">
                <h4>Fill Booking Form</h4>
                <p>Complete our online booking form</p>
            </button>
        `;
    }

    getAboutResponse() {
        return `
            🏢 <strong>About NextEra Event Planner</strong><br><br>
            
            We are a premium event planning and catering company creating unforgettable memories since 2019.
            <br><br>
            <strong>Our Mission:</strong><br>
            Transform your special moments into extraordinary experiences with our premium services.
            <br><br>
            <strong>Our Expertise:</strong><br>
            • 500+ Events Completed<br>
            • 98% Client Satisfaction Rate<br>
            • 5+ Years of Experience<br>
            • Expert Team of Professionals<br><br>
            
            <strong>What Makes Us Special:</strong><br>
            ⭐ Premium Quality - Finest ingredients and materials<br>
            👥 Expert Team - Experienced professionals<br>
            ⏰ Timely Service - Everything delivered on schedule<br>
            💯 Quality Guarantee - 100% satisfaction guarantee<br>
            💡 Creative Solutions - Innovative approach<br>
            ❤️ Personal Touch - Personalized service<br><br>
            
            <button class="service-suggestion" onclick="chatbot.handleQuickAction('contact')">
                <h4>Learn More</h4>
                <p>Get in touch to know more about us</p>
            </button>
        `;
    }

    getGreetingResponse() {
        const greetings = [
            "Hello! 👋 How can I help you plan your perfect event today?",
            "Hi there! 😊 Ready to create some amazing memories?",
            "Hey! 🎉 What kind of event are you planning?",
            "Good day! 🌟 Let's make your event unforgettable!"
        ];
        return greetings[Math.floor(Math.random() * greetings.length)];
    }

    getHelpResponse() {
        return `
            🤝 <strong>How Can I Help You?</strong><br><br>
            
            I'm your NextEra Event Planner assistant! I can help you with:
            <br><br>
            🎉 <strong>Service Information</strong> - Learn about our wedding planning, birthday parties, corporate events, catering, decoration, and photography services<br><br>
            
            💰 <strong>Pricing Details</strong> - Get information about our packages and pricing for different event types<br><br>
            
            📞 <strong>Contact Information</strong> - Find our phone number, email, address, and working hours<br><br>
            
            📅 <strong>Booking Assistance</strong> - Help you get started with booking your event<br><br>
            
            🏢 <strong>About Us</strong> - Learn about our company, experience, and what makes us special<br><br>
            
            <strong>Just ask me anything!</strong> For example:
            <br>• "Tell me about your wedding services"
            <br>• "What are your prices?"
            <br>• "How can I contact you?"
            <br>• "I want to book a birthday party"
        `;
    }

    getDefaultResponse() {
        const responses = [
            "I'd be happy to help! Could you be more specific about what you'd like to know? For example, you can ask about our services, pricing, or how to book an event.",
            "That's interesting! I can help you with information about our event planning services, pricing, contact details, or booking. What would you like to know?",
            "I'm here to assist! You can ask me about our wedding planning, birthday parties, corporate events, catering, decoration, or photography services. What interests you?",
            "Let me help you! I can provide information about our services, pricing, contact information, or help you get started with booking. What do you need?"
        ];
        return responses[Math.floor(Math.random() * responses.length)];
    }

    handleQuickAction(action) {
        const actions = {
            'services': () => this.processMessage('tell me about your services'),
            'pricing': () => this.processMessage('what are your prices'),
            'contact': () => this.processMessage('contact information'),
            'booking': () => this.processMessage('how can I book an event')
        };

        if (actions[action]) {
            actions[action]();
        }
    }

    addMessage(sender, content) {
        const messagesContainer = document.getElementById('chatbotMessages');
        const messageDiv = document.createElement('div');
        messageDiv.className = `message ${sender} new`;
        
        const time = new Date().toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'});
        
        messageDiv.innerHTML = `
            ${content}
            <div class="message-time">${time}</div>
        `;
        
        messagesContainer.appendChild(messageDiv);
        this.scrollToBottom();
        
        // Remove 'new' class after animation
        setTimeout(() => {
            messageDiv.classList.remove('new');
        }, 300);
    }

    scrollToBottom() {
        const messagesContainer = document.getElementById('chatbotMessages');
        messagesContainer.scrollTop = messagesContainer.scrollHeight;
    }

    autoResize(textarea) {
        textarea.style.height = 'auto';
        textarea.style.height = Math.min(textarea.scrollHeight, 100) + 'px';
    }

    containsAny(str, keywords) {
        return keywords.some(keyword => str.includes(keyword));
    }
}

// Initialize chatbot when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    window.chatbot = new EventPlannerChatbot();
});

// Add chatbot CSS to the page
const chatbotCSS = document.createElement('link');
chatbotCSS.rel = 'stylesheet';
chatbotCSS.href = 'css/chatbot.css';
document.head.appendChild(chatbotCSS);





